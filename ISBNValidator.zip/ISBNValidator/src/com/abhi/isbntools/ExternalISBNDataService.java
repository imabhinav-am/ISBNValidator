package com.abhi.isbntools;

public interface ExternalISBNDataService {
    public Book lookup(String isbn);
}
