package com.abhi.isbntools;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

public class StockManagementTests {

    ExternalISBNDataService testWebService ;
    ExternalISBNDataService testDatabaseService ;
    StockManager stockManager ;

    @Before
    public void setup(){
        System.out.println("Setup Running");
        testWebService = mock(ExternalISBNDataService.class);
        testDatabaseService = mock(ExternalISBNDataService.class);
        stockManager = new StockManager();
        stockManager.setWebService(testWebService);
        stockManager.setDatabaseService(testDatabaseService);
    }

//    @Test
//    public void testCanGetCorrectLocatorCode(){
//    // Stub
//        ExternalISBNDataService testWebService = new ExternalISBNDataService() {
//            @Override
//            public Book lookup(String isbn) {
//                return new Book(isbn, "Of Mice And Men", "J. Steinbeck");
//            }
//        };
//
//        ExternalISBNDataService testDatabaseService = new ExternalISBNDataService() {
//            @Override
//            public Book lookup(String isbn) {
//                return null;
//            }
//        };
//
//        String isbn = "0140177396";
//        StockManager stockManager = new StockManager();
//        stockManager.setWebService(testWebService);
//        stockManager.setDatabaseService(testDatabaseService);
//        String locatorCode = stockManager.getLocatorCode(isbn);
//        assertEquals("7396J4",locatorCode);
//    }

    @Test
    public void testCanGetCorrectLocatorCode(){

        when(testWebService.lookup("0140177396")).thenReturn(new Book("0140177396","Of Mice And Men","J. Steinbeck"));
        when(testDatabaseService.lookup("0140177396")).thenReturn(null);

        String isbn = "0140177396";
        String locatorCode = stockManager.getLocatorCode(isbn);
        assertEquals("7396J4",locatorCode);
    }


    @Test
    public void databaseIsUsedIfDataIsPresent(){
        //fail();

        when(testDatabaseService.lookup("0140177396")).thenReturn(new Book("0140177396","abc","abc"));

        String isbn = "0140177396";
        String locatorCode = stockManager.getLocatorCode(isbn);
        //assertEquals("7396J4",locatorCode);

        verify(testDatabaseService).lookup("0140177396");
        verify(testWebService, never()).lookup(anyString());
    }

    @Test
    public void webserviceIsUsedIfDataIsNotPresent(){
//        fail();

        when(testWebService.lookup("0140177396")).thenReturn(null);
        when(testWebService.lookup("0140177396")).thenReturn(new Book("0140177396","abc","abc"));

        String isbn = "0140177396";
        String locatorCode = stockManager.getLocatorCode(isbn);
        //assertEquals("7396J4",locatorCode);

        verify(testDatabaseService).lookup("0140177396");
        verify(testWebService).lookup(anyString());
    }
}
